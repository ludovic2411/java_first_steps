import java.lang.reflect.InvocationTargetException;

import models.Person;
import repositories.Repository;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Repository<Person, Long> personRepo = new Repository<Person, Long>();
		Person p = new Person();
		p.setId(1l);
		p.setFirstName("Bob");
		try {
			personRepo.create(p);
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
