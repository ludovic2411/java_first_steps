package repositories;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import annotations.Champ;
import annotations.Except;

public class Repository<T, TKey> {
	public void create(T obj) throws IllegalArgumentException, IllegalAccessException, NoSuchMethodException, SecurityException, InvocationTargetException 
	{
		Class type = obj.getClass();
		for (Field field : type.getDeclaredFields()) {
			if (field.isAnnotationPresent(Except.class) == false) {
				if (field.isAnnotationPresent(Champ.class)) {
					Champ c = field.getAnnotation(Champ.class);
					System.out.print(c.name() + " : ");
				}
				else {
					System.out.print(field.getName() + " : ");
				}
				
				Method method = type.getDeclaredMethod("get" + capitalize(field.getName()), null);
				System.out.println(method.invoke(obj, null));
			}
			
		}
	}
	public String capitalize(String word) {
		String s = "" + word.toUpperCase().charAt(0);
		s += word.substring(1);
				
		return s;
	}
}
